
function updateBalance(fakeAmount) {
  alert(`₹${fakeAmount} added to your balance! (Fake)`);
}

function playSpinGame() {
  const rewards = [50, 100, 200, 300, 400, 500];
  const result = rewards[Math.floor(Math.random() * rewards.length)];
  alert(`🎉 You won ₹${result}!`);
}

function playAviatorGame() {
  const multiplier = (Math.random() * 4 + 1).toFixed(2);
  alert(`✈️ Plane flew at ${multiplier}x! You cashed out ₹${(100 * multiplier).toFixed(0)} (Fake)`);
}

function playColorTrade(color) {
  const win = Math.random() > 0.5;
  alert(win ? `🎯 Your ${color} bet won! You earned ₹200.` : `😢 Lost this round. Try again.`);
}

function playMindGame() {
  setTimeout(() => {
    alert('🎉 You tapped in time! You win ₹100 (Fake)');
  }, 2000);
}

function playLudoGame() {
  const players = ['You', 'Bot1', 'Bot2', 'Bot3'];
  const winner = players[Math.floor(Math.random() * players.length)];
  alert(`${winner} won ₹300 (Fake Ludo Royale)`);
}
